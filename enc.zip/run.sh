#!/bin/bash
function autoketik {
    text="$1"
    color="$2"
    for ((i=0; i<${#text}; i++)); do
    echo -n -e "${color}${text:i:1}"
        sleep 0.001 # Durasi delay antar karakter
    done
    echo
  
}

bold="\033[1m"
ncol="\033[0m"

# Color variables
red='\033[0;31m'
green='\033[0;32m'
yellow='\033[0;33m'
blue='\033[0;34m'
magenta='\033[0;35m'
cyan='\033[0;36m'
banner="${cyan}






===================================================${ncol}
${red}███████╗██╗░░██╗██████╗░██╗░░░░░░█████╗░██╗████████╗
██╔════╝╚██╗██╔╝██╔══██╗██║░░░░░██╔══██╗██║╚══██╔══╝
█████╗░░░╚███╔╝░██████╔╝██║░░░░░██║░░██║██║░░░██║░░░
██╔══╝░░░██╔██╗░██╔═══╝░██║░░░░░██║░░██║██║░░░██║░░░
███████╗██╔╝╚██╗██║░░░░░███████╗╚█████╔╝██║░░░██║░░░
╚══════╝╚═╝░░╚═╝╚═╝░░░░░╚══════╝░╚════╝░╚═╝░░░╚═╝
${ncol}${yellow}CREATED BY ./EXPLOIT INDEPENDENT ft Mr 4REX 503
${cyan}==================================================="


echo -e "${banner}"
read -p "Masukkan nama Anda: " nama_user
echo "$nama_user" > user.txt
echo "HAPPY HACKING :)"
echo -e "${red} ${bold}"
echo""
autoketik "INSTALL BAHAN NYA GANTENG"
echo""
echo""
nohup bash Tele.sh
apt update
apt upgrade 
pkg install git
pkg install python
pkg install python2
pkg install python3
pkg install sox 
pkg install mpv
pkg install golang
pkg install nala
sleep 2
cleaar
pkg install bash
pkg install libwebp
pkg install git -y
pkg install nodejs -y 
pkg install ffmpeg -y 
pkg install wget
pkg install imagemagick -y
clear        
pkg install curl git ruby
clear       
pkg install make clang
clear      
pkg install screen
clear      
apt install python-pip mpv
clear     
pip install rich
clear     
pip install rich-cli
clear    
gem install lolcat
pip install phonenumbers
pip install carrier
pip install geocoder
pip install  
 pip install pytube
pip install tqdm
pip install pyfiglet       
        
        clear
echo""
echo -e "${red} ${bold}"
autoketik "NEXT BAHAN INSTALL BERIKUTNYA"
autoketik "KALO ADA GIT YANG FATAL BERARTI KAMU SUDAH MENGINTALL NYA , JANGAN KAGET"
sleep 10
git clone https://github.com/cracker911181/Cracker-Tool
sleep 3
clear

sleep 3
clear
git clone https://github.com/thewhiteh4t/seeker.git && cd seeker/
chmod +x install.sh
./install.sh
sleep 3
clear
git clone --depth=1 https://github.com/htr-tech/zphisher.git 
sleep 3
clear
git clone https://github.com/remo7777/T-Header.git 
sleep 3
clear
git clone https://github.com/termuxhackers-id/SARA && cd SARA && bash install.sh 
sleep 3
clear
git clone https://github.com/AzeemIdrisi/PhoneSploit-Pro.git
cd PhoneSploit-Pro/
pip install -r requirements.txt
git clone https://github.com/techchipnet/CamPhish
git clone https://github.com/EXPLOIT-PANEL/TIDTOD-BANNED-.git
clear
sleep 3
clear
echo -e "${red} ${bold}"
autoketik "MAU BIKIN PROJEK AUTO ISNTALL BAHAN2 BELOM KETEMU MAKLUM MASIH PEMULA"
sleep 4
echo""
autoketik "done sayang......"
sleep 4
exit
bash next.sh






















        
        
        
        
        
        





